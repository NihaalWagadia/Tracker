package com.example.nihaal.tracker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class InviteCodeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite_code);
    }
}
